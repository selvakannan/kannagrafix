Title: Winsock SSL Usercontrol With Proxy Support(proxy fixed)
Description: This usercontrol allows you to easily connect to a ssl server using winsock control. It has proxy support also. This control is a revamp of the ssl class by Christopher Hemple. Edit I left a small section of code out for the proxy so here is the fixed version. Vote if you want guys
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=70498&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
