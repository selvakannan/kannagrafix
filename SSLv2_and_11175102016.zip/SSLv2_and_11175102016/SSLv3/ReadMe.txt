SSLClient and SSLServer are companion programs designed to demonstrate Transport Layer Security (TLS) Version 1.0. At the present time, they only support 2 cipher suites:
TLS_RSA_WITH_RC4_128_MD5 (0x00,0x04)
TLS_RSA_WITH_RC4_128_SHA (0x00,0x05)
These 2 suites are supported by virtually all modern browsers and servers, although SHA is more commonly preferred. In addition, 2048 bit asymmetric keys are utilized for the session handshake, since these are strongly recommended by the Internet Engineering Task Force (IETF) since the end of 2013.

In order to support TLS without the use of third party controls or libraries, Microsoft's RSA/SChannel (schannel.dll) is utilized. This library is shipped with all modern Windows Operating Systems. As well, my own NewSocket Class and accompanying Module (mWinsock) are utilized. These 2 modules support IPv6 when it becomes universally available. Although the Cryptography routines will work on most Windows Operating Systems, newSocket will only work on systems that support dual stack (IPv4/IPv6). This more or less restricts it to Windows Vista or better.

Originally, I planned on developing only the Client program without Certificates. But the severe lack of detailed information on TLS using SChannel made troubleshooting difficult if not impossible, and I could not connect with remote servers. So I decided to develop a Server program as well. Several months later, I had 2 programs that would communicate with each other, but I still could not communicate with external servers, and online assistance was virtually non-existent. So I then decided to test the server program using my local browser. That meant providing support for Certificates and a whole new level of complexity. But at least the browser provided a little more troubleshooting information than a remote server.

When first executed, either program will attempt to Acquire a Context handle to a container named "JAC SSL Container". If the container or it's associated Public/Private keys do not exist, they will be created. Signature keys will not be created, as they are not supported by SChannel. This particular step is important, as these keys will be used in later setup steps.

Before the Server program can be used, it needs some Certificate Data. For this I used some programs that are included in the .NET SDK. I never actually attempted it, but supposedly the older SDK's do not support 2048 bit keys. I downloaded Version 4.0 because it had the option not to install the full SDK. I then transferred the following Command Line executables to a separate directory:

70,992 CertMgr.Exe
55,632 makecert.exe
24,912 pvk2pfx.exe
237,392 signtool.exe

The makecert.exe program can be used to create self-signed certificate files. You could create a single certificate, but a browser expects a certificate signed by a Certificate Authority (CA). So we need to create a CA certificate and a Server certificate. Firstly, we create the CA certificate.

makecert -pe -n "CN=MyCert CA" -cy authority -sk "JAC SSL Container" -len 2048 -r "MyCert CA.cer"
  -pe           : Mark generated private key as exportable
  -n            : The certificate name. CN stands for Common Name and is the name that 
                  identifies the certificate. For websites, this is their domain name.
  -cy authority : Creates a certificate authority certificate
  -a sha1       : Use the SHA1 algorithm (Default)
  -sk  <keyName>: Subject's key container name; To be created if not present
  -len <number> : Generated Key Length (default = 1024 Bits)
  -r            : Create a self-signed certificate
      <FileName>: Certificate File Name (DER format)

By default, it will be created in the same directory as "makecert", using the keys that you created earlier. For the next step you will need access to the Microsoft Certificate Manager. You can add it to the Microsoft Management Console (MMC), or you can just run the manager directly (certmgr.msc). From there, you will import the new certificate into the Trusted Root. Right click on "Certificates", and from "All Tasks" click the "Import" function. Browse to the CA file that you just created, and import it. You will be prompted to make sure you really want to do this. This Certificate can now be used to create as many Server certificates as you might need.

For now, we are going to create a Server certificate called "localhost". The reason for this will become apparent when we actually try to get the 2 TLS programs to communicate.

Makecert -len 2048 -pe -n CN="localhost" -sk "JAC SSL Container" -ic "MyCert CA.cer" -ik "JAC SSL Container" -eku 1.3.6.1.5.5.7.3.1 -ss my -sr currentuser -sky exchange -sp "Microsoft RSA SChannel Cryptographic Provider" -sy 12 localhost.cer

  -pe           : Mark generated private key as exportable
  -n            : The certificate name. CN stands for Common Name and is the name that 
                  identifies the certificate. For websites, this is their domain name.
  -cy authority : Creates a certificate authority certificate
  -a sha1       : Use the SHA1 algorithm (Default)
  -sk  <keyName>: Subject's key container name; To be created if not present
  -len <number> : Generated Key Length (default = 1024 Bits)
  -r            : Create a self-signed certificate
  -ic  <file>   : Issuer's certificate file
  -ik  <keyName>: Issuer's key container name
  -eku          : Comma separated enhanced key usage OIDs. This one is limited to Server                               Authentication
  -ss  <store>  : Subject's certificate store name. We are using the Personal store "my"
  -ir <location>: Issuer's certificate store location (Default = currentuser)
  -sky <keytype>: Subject key type <signature|exchange|<integer>>
  -sp <provider>: Subject's CryptoAPI provider's name
  -sy  <type>   : Subject's CryptoAPI provider's type
      <FileName>: Certificate File Name (DER format)

This certificate should be stored automatically in the "Personal" store, but if it isn't, then import it there.

If you are using a different browser than Internet Explorer, you will need to import the CA file into the Trusted Root store for the browser. This applies to any Self-Signed Certificate that you might want to use. The browser will attempt to verify that the site exists, and of course "localhost" does not. For example, if you want to use "www.mikestoolbox.org" with your browser, you should import the CA certificate into the Trusted Root for the browser. "mikestoolbox.org" does exist, but importing his CA certificate into the root avoids answering the "Do you really want to trust this site?" question all the time. All you need to do is output the second certificate that his site sends into "Mike's Toolbox Test CA.cer". For your convenience, a routine to output Certificate data has been added to the Client program. Simply check the "Save Certificates" box before you connect to a site.

Now it is time to test your handy work. Open 2 sessions of the Visual Basic Development Environment. Load the Client program in one, and the Server program in the other. Start the Server program and move it to the lower right corner. This is done so you can see both windows at the same time, and the Server will show that it is listening on port 443. Now start the Client program and move it to the upper left corner. Bring the Server window back to the front by clicking on it in the Task Bar. There are 2 URLs loaded into the Combo Box at the top of the Client window. If you click on the "localhost" one, and localhost is properly identified in your "HOSTS" file as 127.0.0.1, you should connect with the Server window. If all is successful, a session will be negotiated and a simple message will be displayed in the Client. There are many debug messages displayed in each window and in the Immediate window in VB, which can be very helpful in troubleshooting.

You can test the Client program with an outside server by using the "https://www.mikestoolbox.org" item from the Combo Box. It should return something similar to the messages that are shown in:
http://www.yellowhead.com/TLS_Handshake.htm
You should find this Web page very helpful in understanding how TLS actually works.

You can test the Server program independently by using the URL "https://localhost" in your browser. If everything works correctly, you should see the same message as when you connected the Client and Server programs directly. You must have imported the "MyCert CA" certificate into the browser's store in order for this to work. Some browser versions do not give you much information if there is a problem.

